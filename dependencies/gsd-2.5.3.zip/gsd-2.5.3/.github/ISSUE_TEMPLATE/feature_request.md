---
name: Feature request
about: Suggest a new GSD feature
title: ''
labels: 'enhancement'
assignees: ''

---

## Description

<!-- What new capability would you like in GSD? -->

## Proposed solution

<!-- How should this capability be implemented? -->
<!-- What might the user API look like? -->

## Additional context

<!-- What additional information is helpful to understand this request? -->

## Developer

<!-- Who should implement the new functionality? We would welcome your contribution! -->
