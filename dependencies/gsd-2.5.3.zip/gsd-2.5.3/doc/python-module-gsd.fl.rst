.. Copyright (c) 2016-2022 The Regents of the University of Michigan
.. Part of GSD, released under the BSD 2-Clause License.

gsd.fl module
^^^^^^^^^^^^^

.. automodule:: gsd.fl
    :synopsis: The file layer provides a low level API for directly accessing gsd files.
    :members:
