.. Copyright (c) 2016-2022 The Regents of the University of Michigan
.. Part of GSD, released under the BSD 2-Clause License.

Credits
=======

The following people contributed to GSD.

* Joshua A. Anderson, University of Michigan
* Carl Simon Adorf, University of Michigan
* Bradley Dice, University of Michigan
* Jenny W. Fothergill, Boise State University
* Jens Glaser, University of Michigan
* Vyas Ramasubramani, University of Michigan
* Luis Y. Rivera-Rivera, University of Michigan
* Brandon Butler, University of Michigan
* Arthur Zamarin, Gentoo Linux
* Alexander Stukowski, OVITO GmbH
