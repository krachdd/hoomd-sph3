.. Copyright (c) 2016-2022 The Regents of the University of Michigan
.. Part of GSD, released under the BSD 2-Clause License.

gsd.hoomd module
^^^^^^^^^^^^^^^^

.. automodule:: gsd.hoomd
    :synopsis: Reference implementation for reading/writing hoomd schema GSD files.
    :members:
