.. Copyright (c) 2016-2022 The Regents of the University of Michigan
.. Part of GSD, released under the BSD 2-Clause License.

License
=======

GSD is available under the following license.

.. literalinclude:: ../LICENSE
