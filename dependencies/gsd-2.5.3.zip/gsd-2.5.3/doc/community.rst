.. Copyright (c) 2016-2022 The Regents of the University of Michigan
.. Part of GSD, released under the BSD 2-Clause License.

User community
==============

hoomd-users mailing list
--------------------------

**GSD** primarily exists as a file format for HOOMD-blue, so please use the
`hoomd-users <https://groups.google.com/d/forum/hoomd-users>`_ mailing list.
Subscribe for release announcements, to post questions questions for advice on
using the software, and discuss potential new features.

Issue tracker
-------------

File bug reports on `GSD's issue tracker
<https://github.com/glotzerlab/gsd/issues>`_.
