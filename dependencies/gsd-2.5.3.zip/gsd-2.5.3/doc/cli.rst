.. Copyright (c) 2016-2022 The Regents of the University of Michigan
.. Part of GSD, released under the BSD 2-Clause License.

gsd command line interface
==========================

**GSD** provides a command line interface for rapid inspection of files from the command line.

.. automodule:: gsd.__main__
    :synopsis: GSD CLI.
